@echo off
cd /d %~dp0
python scripts\check_progress.py configs\config_MURA24m_E662_w050_080_customR_beta75.json
pause
