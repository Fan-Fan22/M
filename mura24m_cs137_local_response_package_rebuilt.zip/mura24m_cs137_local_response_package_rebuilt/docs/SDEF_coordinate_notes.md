# SDEF and coordinate convention

The script generates:

```text
SDEF PAR=2 ERG=0.662 POS=x y z
```

- `PAR=2`: photon source
- `ERG=0.662`: 662 keV gamma ray, in MeV
- `POS=x y z`: point-source position in cm

Coordinate conversion:

```text
tan(alpha) = x / (-z)
tan(beta)  = y / (-z)
x^2 + y^2 + z^2 = r^2
```

Examples:

```text
r=30, alpha=-45, beta=-45
POS=-17.3205 -17.3205 -17.3205

r=700, alpha=45, beta=75
POS=175.394 654.579 -175.394
```
