c ======================================================================
c Placeholder MCNP template for MURA24m response generation.
c Replace this file with your real MURA24m_f8_E662_w050_080.i geometry.
c The builder replaces SDEF and NPS automatically.
c ======================================================================

c Put your real cells, surfaces, materials, transforms, and F8 tally cards here.

{{SDEF_CARD}}

c Example tally placeholder only. Replace with your real F8/F18 tally setup.
c F18:P detector_cell_list
c E18 0.5 0.8

{{NPS}}
