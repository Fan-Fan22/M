# MURA24m Cs-137 Local Response Package

This is a rebuilt package for the MCNP MURA24m coded-aperture response workflow.

## Default config

`configs/config_MURA24m_E662_w050_080_customR_beta75.json`

Key values:

```json
"source_energy_mev": 0.662,
"nps": 10000000,
"alpha_grid_deg": [-45.0, 45.0, 37],
"beta_grid_deg": [-45.0, 75.0, 49],
"detector_pixels": [19, 19],
"mpi_np": 20,
"max_workers": 8
```

Total jobs:

```text
22 × 37 × 49 = 39886
```

Expected response shape:

```text
(22, 37, 49, 1, 361)
```

## Important

The included MCNP template is only a placeholder. Replace:

```text
templates/MURA24m_f8_E662_w050_080.template.i
```

with your real MURA24m MCNP geometry template, or edit `template_input` in the config.

## Run

```bat
cd /d D:\重建\662\mura24m_cs137_local_response_package
python scripts\build_response_library_f8.py configs\config_MURA24m_E662_w050_080_customR_beta75.json
```

Generate inputs only:

```bat
python scripts\build_response_library_f8.py configs\config_MURA24m_E662_w050_080_customR_beta75.json --generate-only
```

Check progress:

```bat
python scripts\check_progress.py configs\config_MURA24m_E662_w050_080_customR_beta75.json
```

Clean bad or incomplete outputs, dry run:

```bat
python scripts\clean_incomplete_outputs.py configs\config_MURA24m_E662_w050_080_customR_beta75.json
```

Actually delete bad outputs:

```bat
python scripts\clean_incomplete_outputs.py configs\config_MURA24m_E662_w050_080_customR_beta75.json --delete
```

## Current recommended MPI setting

For your `2 × AMD EPYC 9V74 80-Core` machine, the stable measured setting was:

```json
"mpi_np": 20,
"max_workers": 8
```

Measured throughput was about `180 jobs/hour`, better than `16×8` and `10×16` in your tests.
