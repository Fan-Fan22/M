#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse,json
from pathlib import Path
BAD_MARKERS=['bad trouble','fatal error','run terminated because of bad trouble']
def is_bad_or_incomplete(p:Path)->bool:
    if not p.exists() or p.stat().st_size==0: return True
    s=p.read_text(encoding='utf-8',errors='ignore').lower()
    if any(m in s for m in BAD_MARKERS): return True
    return 'run terminated when' not in s or 'particle histories were done' not in s
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('config',type=Path); ap.add_argument('--delete',action='store_true'); args=ap.parse_args()
    cfg=json.loads(args.config.read_text(encoding='utf-8'))
    base=args.config.parent.parent if args.config.parent.name=='configs' else Path.cwd(); jobs=base/cfg['jobs_dir']
    bad=[p for p in jobs.rglob('*.o') if is_bad_or_incomplete(p)]
    print(f'bad/incomplete outputs: {len(bad)}')
    for p in bad[:100]: print(p)
    if args.delete:
        for p in bad: p.unlink(missing_ok=True)
        print(f'deleted: {len(bad)}')
if __name__=='__main__': main()
