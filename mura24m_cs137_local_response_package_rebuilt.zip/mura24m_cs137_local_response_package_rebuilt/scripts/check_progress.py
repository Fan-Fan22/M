#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('config',type=Path); args=ap.parse_args()
    cfg=json.loads(args.config.read_text(encoding='utf-8'))
    base=args.config.parent.parent if args.config.parent.name=='configs' else Path.cwd()
    jobs=base/cfg['jobs_dir']; outs=list(jobs.rglob('*.o')); total=len(list(jobs.rglob('*.i')))
    print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print(f'jobs_dir: {jobs}'); print(f'input files : {total}'); print(f'output files: {len(outs)}')
    if total: print(f'progress: {len(outs)}/{total} = {100*len(outs)/total:.2f}%')
    for p in sorted(outs,key=lambda x:x.stat().st_mtime,reverse=True)[:20]:
        st=p.stat(); print(f'{p.name}\t{st.st_size}\t{datetime.fromtimestamp(st.st_mtime)}')
if __name__=='__main__': main()
