#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Build a local MCNP F8 response library for a MURA coded-aperture gamma camera.

Functions:
1. Generate one MCNP input per source grid point.
2. Optionally run MCNP in parallel.
3. Parse F8 tally output into an NPZ response library.

Coordinate convention:
    tan(alpha) = x / (-z)
    tan(beta)  = y / (-z)
    x^2 + y^2 + z^2 = r^2
Camera front direction is -z.
"""
from __future__ import annotations
import argparse, concurrent.futures as cf, csv, json, math, os, re, subprocess, sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import numpy as np

FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?")

@dataclass(frozen=True)
class Job:
    index:int; ir:int; ia:int; ib:int
    r:float; alpha:float; beta:float
    x:float; y:float; z:float
    name:str; job_dir:Path; input_path:Path; output_path:Path

def load_config(path: Path) -> dict[str, Any]:
    cfg=json.loads(path.read_text(encoding='utf-8'))
    cfg['_config_path']=str(path)
    cfg['_base_dir']=str(path.parent.parent if path.parent.name=='configs' else Path.cwd())
    return cfg

def as_grid(v: Any) -> list[float]:
    if isinstance(v,(list,tuple)) and len(v)==3 and isinstance(v[2],int):
        return [float(x) for x in np.linspace(float(v[0]),float(v[1]),int(v[2]))]
    if isinstance(v,(list,tuple)): return [float(x) for x in v]
    raise TypeError(f'Invalid grid: {v!r}')

def fmt_num(x: float) -> str:
    return f'{x:.3f}'.replace('-','m').replace('.','p')

def source_pos_from_r_alpha_beta(r:float, alpha_deg:float, beta_deg:float):
    ta=math.tan(math.radians(alpha_deg)); tb=math.tan(math.radians(beta_deg))
    minus_z=r/math.sqrt(1.0+ta*ta+tb*tb)
    return minus_z*ta, minus_z*tb, -minus_z

def make_jobs(cfg:dict[str,Any], base_dir:Path) -> list[Job]:
    r_grid=as_grid(cfg['r_grid_cm']); a_grid=as_grid(cfg['alpha_grid_deg']); b_grid=as_grid(cfg['beta_grid_deg'])
    jobs_dir=base_dir/cfg['jobs_dir']; jobs=[]; idx=0
    for ir,r in enumerate(r_grid):
        for ia,a in enumerate(a_grid):
            for ib,b in enumerate(b_grid):
                x,y,z=source_pos_from_r_alpha_beta(r,a,b)
                name=f"j{idx:05d}_ir{ir:02d}_ia{ia:02d}_ib{ib:02d}_r{fmt_num(r)}_a{fmt_num(a)}_b{fmt_num(b)}"
                job_dir=jobs_dir/name
                jobs.append(Job(idx,ir,ia,ib,r,a,b,x,y,z,name,job_dir,job_dir/f'{name}.i',job_dir/f'{name}.o'))
                idx+=1
    return jobs

def replace_or_insert_sdef(text:str, sdef_card:str) -> str:
    if '{{SDEF_CARD}}' in text: return text.replace('{{SDEF_CARD}}',sdef_card)
    lines=text.splitlines(); out=[]; replaced=False
    for line in lines:
        if re.match(r'^\s*sdef\b',line,flags=re.I): out.append(sdef_card); replaced=True
        else: out.append(line)
    if not replaced: out += ['', 'c --- source card inserted by build_response_library_f8.py', sdef_card]
    return '\n'.join(out)+'\n'

def replace_or_insert_nps(text:str, nps:int) -> str:
    if '{{NPS}}' in text: return text.replace('{{NPS}}',str(int(nps)))
    lines=text.splitlines(); out=[]; replaced=False
    for line in lines:
        if re.match(r'^\s*nps\b',line,flags=re.I): out.append(f'NPS {int(nps)}'); replaced=True
        else: out.append(line)
    if not replaced: out.append(f'NPS {int(nps)}')
    return '\n'.join(out)+'\n'

def render_input(template:str, cfg:dict[str,Any], job:Job) -> str:
    sdef=f"SDEF PAR={int(cfg.get('source_particle',2))} ERG={float(cfg['source_energy_mev']):.8g} POS={job.x:.8g} {job.y:.8g} {job.z:.8g}"
    extra=str(cfg.get('sdef_extra','')).strip()
    if extra: sdef+=' '+extra
    text=template
    repl={'{{JOB_NAME}}':job.name,'{{JOB_INDEX}}':str(job.index),'{{IR}}':str(job.ir),'{{IA}}':str(job.ia),'{{IB}}':str(job.ib),'{{R_CM}}':f'{job.r:.8g}','{{ALPHA_DEG}}':f'{job.alpha:.8g}','{{BETA_DEG}}':f'{job.beta:.8g}','{{SOURCE_X}}':f'{job.x:.8g}','{{SOURCE_Y}}':f'{job.y:.8g}','{{SOURCE_Z}}':f'{job.z:.8g}','{{SOURCE_ENERGY_MEV}}':f"{float(cfg['source_energy_mev']):.8g}"}
    for k,v in repl.items(): text=text.replace(k,v)
    text=replace_or_insert_sdef(text,sdef)
    text=replace_or_insert_nps(text,int(cfg.get('nps',1000000)))
    return text

def write_inputs(cfg, base_dir, jobs):
    template_path=base_dir/cfg['template_input']
    if not template_path.exists(): raise FileNotFoundError(f'Template input not found: {template_path}')
    template=template_path.read_text(encoding='utf-8',errors='replace')
    overwrite=bool(cfg.get('overwrite_inputs',True))
    for i,job in enumerate(jobs,1):
        job.job_dir.mkdir(parents=True,exist_ok=True)
        if overwrite or not job.input_path.exists(): job.input_path.write_text(render_input(template,cfg,job),encoding='utf-8')
        if i==1 or i==len(jobs) or i%max(1,len(jobs)//10)==0: print(f'generated [{i}/{len(jobs)}] {job.name}',flush=True)

def write_manifest(cfg,base_dir,jobs):
    if not bool(cfg.get('write_manifest_csv',True)): return
    manifest=base_dir/cfg['jobs_dir']/ 'manifest.csv'; manifest.parent.mkdir(parents=True,exist_ok=True)
    with manifest.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['index','ir','ia','ib','r_cm','alpha_deg','beta_deg','x_cm','y_cm','z_cm','job_name','input','output'])
        for j in jobs: w.writerow([j.index,j.ir,j.ia,j.ib,j.r,j.alpha,j.beta,j.x,j.y,j.z,j.name,j.input_path,j.output_path])
    print(f'manifest: {manifest}')

def build_mcnp_cmd(cfg,job):
    cmd=[str(cfg.get('mcnp_exe','mc6mpi.exe')),f'i={job.input_path.name}',f'o={job.output_path.name}']
    if bool(cfg.get('use_mpiexec',True)):
        cmd=[str(cfg.get('mpiexec_exe','mpiexec')),str(cfg.get('mpi_np_flag','-n')),str(int(cfg.get('mpi_np',1))),*[str(x) for x in cfg.get('mpiexec_args',[])],*cmd]
    return cmd

def run_one(cfg,job):
    overwrite=bool(cfg.get('overwrite_outputs',False))
    if job.output_path.exists() and job.output_path.stat().st_size>0 and not overwrite: return job.index,job.name,0
    if overwrite:
        for p in [job.output_path,job.job_dir/'runtpe',job.job_dir/'runtpf']:
            try: p.unlink()
            except FileNotFoundError: pass
    try:
        p=subprocess.run(build_mcnp_cmd(cfg,job),cwd=str(job.job_dir),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if p.returncode!=0: (job.job_dir/f'{job.name}.runlog.txt').write_text(p.stdout or '',encoding='utf-8',errors='replace')
        return job.index,job.name,int(p.returncode)
    except Exception as e:
        (job.job_dir/f'{job.name}.runlog.txt').write_text(str(e),encoding='utf-8',errors='replace')
        return job.index,job.name,999

def run_jobs(cfg,jobs):
    max_workers=int(cfg.get('max_workers',1))
    print(f"run_mcnp=True, max_workers={max_workers}, mpi_np={cfg.get('mpi_np')}",flush=True)
    done=0
    with cf.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs=[ex.submit(run_one,cfg,j) for j in jobs]
        for fut in cf.as_completed(futs):
            idx,name,rc=fut.result(); done+=1
            print(f'[{done}/{len(jobs)}] finished {name} rc={rc}',flush=True)

def output_is_complete(path:Path) -> bool:
    if not path.exists() or path.stat().st_size==0: return False
    tail=path.read_text(encoding='utf-8',errors='ignore')[-5000:].lower()
    return 'run terminated when' in tail and 'particle histories were done' in tail and 'bad trouble' not in tail and 'fatal error' not in tail

def parse_tally_values_from_output(path:Path,tally_number:int,n_values:int):
    text=path.read_text(encoding='utf-8',errors='ignore'); low=text.lower()
    starts=[m.start() for m in re.finditer(rf'\btally\s+{int(tally_number)}\b',low,flags=re.I)]
    if not starts: return None
    block=text[max(starts):max(starts)+300000]
    stop=len(block)
    for marker in ['status of the statistical checks','1status of the statistical','tally fluctuation chart']:
        k=block.lower().find(marker)
        if k>1000: stop=min(stop,k)
    block=block[:stop]
    vals=[]
    for line in block.splitlines():
        nums=[float(x) for x in FLOAT_RE.findall(line)]
        if len(nums)>=3:
            relerr=nums[-1]; val=nums[-2]
            if 0<=relerr<=1.0e3: vals.append(val)
    if len(vals)>=n_values: return np.asarray(vals[:n_values],dtype=np.float32)
    nums=[float(x) for x in FLOAT_RE.findall(block)]
    if len(nums)>=n_values: return np.asarray(nums[-n_values:],dtype=np.float32)
    return None

def parse_outputs(cfg,base_dir,jobs):
    if not bool(cfg.get('parse_outputs',True)): return
    px=cfg.get('detector_pixels',[19,19]); n_pix=int(px[0])*int(px[1]); n_win=len(cfg.get('energy_windows_mev',[[0.5,0.8]])); tally_number=int(cfg.get('tally_number',18)); allow=bool(cfg.get('allow_missing_outputs',False))
    r_grid=as_grid(cfg['r_grid_cm']); a_grid=as_grid(cfg['alpha_grid_deg']); b_grid=as_grid(cfg['beta_grid_deg'])
    H=np.zeros((len(r_grid),len(a_grid),len(b_grid),n_win,n_pix),dtype=np.float32)
    parsed=missing=0; failures=[]
    for job in jobs:
        if not output_is_complete(job.output_path):
            missing+=1
            if not allow: failures.append(f'missing/incomplete: {job.output_path}')
            continue
        arr=parse_tally_values_from_output(job.output_path,tally_number,n_win*n_pix)
        if arr is None or arr.size<n_win*n_pix:
            failures.append(f'parse failed: {job.output_path}'); continue
        H[job.ir,job.ia,job.ib,:,:]=arr[:n_win*n_pix].reshape(n_win,n_pix); parsed+=1
    if failures and not allow:
        print('\n'.join(failures[:20]),file=sys.stderr); raise RuntimeError(f'parse failed/missing count={len(failures)}')
    out=base_dir/cfg['output_npz']; out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,H=H,r_grid_cm=np.asarray(r_grid,dtype=np.float32),alpha_grid_deg=np.asarray(a_grid,dtype=np.float32),beta_grid_deg=np.asarray(b_grid,dtype=np.float32),energy_windows_mev=np.asarray(cfg.get('energy_windows_mev',[]),dtype=np.float32),detector_pixels=np.asarray(px,dtype=np.int32),parsed_jobs=np.asarray(parsed,dtype=np.int64),missing_jobs=np.asarray(missing,dtype=np.int64),parse_failures=np.asarray(len(failures),dtype=np.int64))
    print(f'response shape = {H.shape}'); print(f'parsed jobs = {parsed}, missing jobs = {missing}, parse failures = {len(failures)}'); print(f'total response sum = {float(H.sum()):.8e}'); print(f'saved: {out}')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('config',type=Path); ap.add_argument('--generate-only',action='store_true'); ap.add_argument('--no-parse',action='store_true'); args=ap.parse_args()
    cfg=load_config(args.config); base_dir=Path(cfg['_base_dir']).resolve(); os.chdir(base_dir)
    jobs=make_jobs(cfg,base_dir); print(f'estimated jobs = {len(jobs)}')
    write_inputs(cfg,base_dir,jobs); write_manifest(cfg,base_dir,jobs)
    if args.generate_only: print('generate-only done'); return
    if bool(cfg.get('run_mcnp',False)): run_jobs(cfg,jobs)
    else: print('run_mcnp=False, skip MCNP execution')
    if args.no_parse: print('no-parse requested'); return
    parse_outputs(cfg,base_dir,jobs)
if __name__=='__main__': main()
